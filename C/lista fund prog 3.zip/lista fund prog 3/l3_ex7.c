#include <stdio.h>
int main()
{
    int n, i, a, b, proximo;
    scanf("%d", &n);
    a = 0;
    b = 1;
    for (i = 0; i < n; i++) {
        printf("%d ", a);
        proximo = a + b;
        a = b;
        b = proximo;
    }
    return 0;
}
