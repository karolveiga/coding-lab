#include <stdio.h>
int main()
{
    int num, cont;
    float soma, media;
    scanf("%d", &num);

    cont = 0;
    soma = 0;
    while (num != -1000) {
        if (num > 0) {
            cont++;
            soma = soma + num;
        }
        scanf("%d", &num);
    }
    media = soma / cont;

    printf("%d valores positivos foram fornecidos\n", cont);
    printf("Media: %.2f\n", media);

    return 0;
}
