#include <stdio.h>
int main()
{
    int chico, ze, anos;
    chico = 150;
    ze = 110;
    anos = 0;
    while (ze <= chico) {
        chico = chico + 2;
        ze = ze + 3;
        anos++;
    }
    printf("%d\n", anos);
    return 0;
}
