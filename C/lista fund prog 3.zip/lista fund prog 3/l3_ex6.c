#include <stdio.h>
int main()
{
    int n, i, fat;
    scanf("%d", &n);
    fat = 1;
    for(i=n; i>=1; i--){
        fat=fat*i;
    }
    printf("%d", fat);
    return 0;
}
