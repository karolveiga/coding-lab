#include <stdio.h>
int main(){
    int qtdMedias, i;
    float media1, media2, media3, mediaTotal;

    scanf("%d", &qtdMedias);
    for (i=1; i<= qtdMedias; i++){
        scanf("%f %f %f", &media1, &media2, &media3);
        mediaTotal = ((media1*2)+(media2*3)+(media3*5))/10;
        printf("%.1f\n", mediaTotal);
    }
    return 0;
}
