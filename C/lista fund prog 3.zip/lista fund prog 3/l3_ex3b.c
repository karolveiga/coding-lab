#include <stdio.h>
int main()
{
    int x, y, i, resto, cont;
    scanf("%d%d", &x, &y);
    cont = 0;
    for (i=y+1; i< x; i++){ //y+1 para nao contar os extremos
        resto = i % 2;
        if (resto == 1){
            if (i % x == 0 || i % y == 0){
                cont++;
            }
        }
    }
    printf("%d impares divisores de x ou y\n", cont);
    return 0;
}
