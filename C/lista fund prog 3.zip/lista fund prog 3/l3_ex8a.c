#include <stdio.h>

int main()
{
    int t, i, num, maior;

    scanf("%d", &t);
    scanf("%d", &maior);
    for (i = 2; i <= t; i++) {
        scanf("%d", &num);
        if (num > maior) {
            maior = num;
        }
    }

    printf("%d\n", maior);
    return 0;
}
