#include <stdio.h>
int main(){
    int num, n1, n2, soma, mult;
    for (num=1000; num <=9999; num++){
        n1=num/100;
        n2=num%100;
        soma=n1+n2;
        mult=soma*soma;
        if (mult == num){
            printf("%d\n", mult);
        }
    }
    return 0;
}
