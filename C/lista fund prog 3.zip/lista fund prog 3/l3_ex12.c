#include <stdio.h>
#include <stdlib.h>
#include <time.h>

int main()
{
    int numero, chute, tentativas;

    srand(time(NULL));

    numero = rand() % 500 + 1;
    tentativas = 0;

    scanf("%d", &chute);

    while (chute != numero) {
        tentativas++;

        if (chute > numero) {
            printf("Maior\n");
        }
        else {
            printf("Menor\n");
        }

        scanf("%d", &chute);
    }

    tentativas++;

    if (tentativas >= 1 && tentativas <= 3) {
        printf("\\o/\n");
    }
    else if (tentativas >= 4 && tentativas <= 6) {
        printf(":-D\n");
    }
    else if (tentativas >= 7 && tentativas <= 10) {
        printf(":-)\n");
    }
    else {
        printf(":-\\\n");
    }

    return 0;
}
