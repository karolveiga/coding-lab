#include <stdio.h>

int main()
{
    float dep, rend; //variaveis
    scanf("%f %f", &dep, &rend);
    /*usei o float, pois s�o valores reais que foram
    utilizados no programa anterior*/

    printf("Deposito: R$%f \n", dep);
    printf("Rendimento: R$%f \n", rend/100*dep);
    printf("Final do mes: R$%f \n", dep + rend/100*dep);
    printf("\n");
    return 0;

    /*a vantagem de usar uma variavel � que o usu�rio declara
    os valores que ele quer utilizar, definindo um macro, isso
    n�o � poss�vel. todavia, o uso das v�riaveis deixa o tamanho
    do programa maior, o uso dos macros reduz o custo dele*/
}
