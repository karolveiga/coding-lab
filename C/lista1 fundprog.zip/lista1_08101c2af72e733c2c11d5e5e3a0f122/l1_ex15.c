#include <stdio.h>

#define DIA 86400
#define HORA 3600
#define MIN 60

int main(){
    int segundos;
    int dias, restDias, horas, restHoras, minutos, restMinutos;

    scanf("%d", &segundos);
    //entrada

    //opera��es abaixo
    dias = segundos / DIA;
    restDias = segundos % DIA;
    horas = restDias / HORA;
    restHoras = restDias % HORA;
    minutos = restHoras / MIN;
    restMinutos = restHoras % MIN; //s�o os segundos tambem

    //saidas
    printf("%d segundos correspodem a ", segundos);
    printf("%d dias, ", dias);
    printf("%d horas, ", horas);
    printf("%d minutos, ", minutos);
    printf("%d segundos.", restMinutos);

    return 0;
}
