#include  <stdio.h>
int main(){
    int distKm;
    float combusLit;
    float consumoMedio;
    //achei que separar assim fica mais organizado

    scanf("%d %f", &distKm, &combusLit);
    consumoMedio = distKm / combusLit;
    printf("%.3f km/1", consumoMedio);

    return 0;
}
