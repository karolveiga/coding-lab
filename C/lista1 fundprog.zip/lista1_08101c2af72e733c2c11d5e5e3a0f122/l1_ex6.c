#include <stdio.h>
int main()
{
    int n1, n2, media;
    scanf("%d %d", &n1, &n2);
    media = (n1 + n2)/2;
    printf("%d", media);
    return 0;
    /*neste modelo, o programa s� ir� fazer
    as medias de valores inteiros, tendo saida
    de um numero inteiro tamb�m, sem quebrar o
    numero, embora num caso de n1=2 e n2=3 essa
    quebra necessaria, por isso fiz a vers�o 2
    do mesmo exerc�cio para imprimir a media
    corretamente*/
}
