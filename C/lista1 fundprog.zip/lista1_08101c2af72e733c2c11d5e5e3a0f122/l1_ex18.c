#include <stdio.h>

int main(){
    float distancia, gastoGasolina, gastoPedagio, gastoTotal;
    int pedagios;

    scanf("%f %d", &distancia, &pedagios);

    gastoGasolina = (distancia / 15) * 5.6;
    gastoPedagio = pedagios * 8;
    gastoTotal = gastoGasolina + gastoPedagio;

    printf("%.2f\n", gastoTotal);

    return 0;
}
