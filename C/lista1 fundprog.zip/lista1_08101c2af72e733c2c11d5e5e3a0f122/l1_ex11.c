#include <stdio.h>
#include <stdlib.h>

int main(){
    int maxAB, a, b, c;

    scanf("%d %d %d", &a, &b, &c);
    maxAB = (a + b + abs(a - b)) / 2;
    if (maxAB >= c){
        printf("%d eh o maior", maxAB);
    }
    else {
        printf("%d eh o maior", c);
    }
    return 0;
}
