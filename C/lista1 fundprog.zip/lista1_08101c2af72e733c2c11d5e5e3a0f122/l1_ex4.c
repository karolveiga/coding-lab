#include <stdio.h>
int main()
{
    int i;
    char c;
    float f;

    printf("Digite um valor inteiro: \n");
    scanf("%d" , &i);

    printf("Digite um caractere: \n");
    scanf(" %c", &c);

    printf("Entre com um numero de ponto flutuante (valor n�o inteiro): \n");
    scanf("%f", &f);

    printf("%d %c %f", i, c, f);

    return 0;
}
