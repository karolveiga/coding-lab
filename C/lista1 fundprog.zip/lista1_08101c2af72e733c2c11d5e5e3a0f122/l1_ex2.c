#include <stdio.h>

int main()
{
    float dep, rend, ret; //variaveis
    scanf("%f %f %f", &dep, &rend, &ret);
    /*usei o float, pois s�o valores reais que foram
    utilizados no programa anterior*/

    printf("Deposito: R$%f \n", dep);
    printf("Rendimento: R$%f \n", rend/100*dep);
    printf("Retirada: R$%f \n", ret);
    printf("Final do mes: R$%f \n", (dep + (rend/100*dep)) - ret);
    printf("\n");
    return 0;
}
