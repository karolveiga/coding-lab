#include <stdio.h>

#define PI 3.14159

int main(){
    double r, volume;
    //alterei o flooat para nao dar overflow ao inserir 1523

    scanf("%lf", &r);
    // o %lf para a variavel double

    volume = (4 * PI * (r * r * r))/3;

    printf("VOLUME = %.3lf\n", volume);

    return 0;
}
