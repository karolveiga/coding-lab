#include <stdio.h>
#include <stdlib.h>

int main(){
    int minAB, minTodos;
    int a, b, c;
    // fiz assim para organizar melhor as variaveis

    scanf("%d %d %d", &a, &b, &c);
    minAB = (a + b - abs(a - b)) / 2;
    /*inverti o sinal do abs para calcular
    o min, pois eh a logica inversa do maxAB*/
    minTodos = (minAB + c - abs(minAB - c)) /2;
    printf("%d eh o menor", minTodos);

    return 0;
}
