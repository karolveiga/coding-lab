#include <stdio.h>
int main(){
    int base, altura, perimetro;

    printf("Insira o valor da base: \n");
    scanf("%d", &base);
    printf("Insira o valor da altura: \n");
    scanf("%d", &altura);

    perimetro = (2 * base) + (2 * altura);
    printf("%d", perimetro);

    return 0;
}
