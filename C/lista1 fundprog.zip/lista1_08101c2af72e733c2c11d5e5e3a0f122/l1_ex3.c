#include <stdio.h>
int main()
{
    char c;
    int i;
    float f;
    /*eu notei voc� fez uma pegadinha no
    enunciado do exerc�cio, professora! hehe
    pois voc� pediu pra deixar na ordem char,
    int e float, mas no c�digo de exemplo
    voc� deixou na ordem int, float e char*/

    printf("Digite um caractere: \n");
    scanf("%c", &c);
    printf("Digite um valor inteiro: \n");
    scanf("%d", &i);
    printf("Entre com um numero de ponto flutuante (valor nao inteiro): \n");
    scanf("%f", &f);
    printf("%c %d %f", c, i, f);

    return 0;

}
