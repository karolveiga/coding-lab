# include <stdio.h>
int main () {
    char aux ;

    printf (" Digite um caracter : ");
    scanf ("%c", &aux );
    printf ("%d", aux );

    return 0;
    /*nao eh um erro, o numero eh o codigo do
    caractere na tabela ASCII*/
}
