#include <stdio.h>
int main (){
    int dinheiroTotal;
    int ced50, rest50, ced5, rest5;

    scanf("%d", &dinheiroTotal);
    //vai ler o valor inteiro

    ced50 = dinheiroTotal / 50;
    rest50 = dinheiroTotal % 50;
    ced5 =  rest50 / 5;
    rest5 = rest50 % 5;
    //operacoes para verificar as cedulas necessarias

    printf("R$ %d, ", dinheiroTotal);
    printf("%d cedulas de 50, ", ced50);
    printf("%d cedulas de 5, ", ced5);
    printf("%d cedulas de 1.", rest5);

    return 0;
}
