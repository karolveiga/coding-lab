#include <stdio.h>
int main()
{
    float n1, n2, media;

    scanf("%f %f", &n1, &n2);
    media = (n1 + n2)/2;
    printf("%f", media);
    return 0;
    /*ele ainda vai ler valores inteiros, pois o
    usuario nao sabe identificar isso no programa,
    mesmo que o programa na verdade esteja lendo
    um float, e esse float eh importante para que
    a media seja calculada corretamente*/
}

