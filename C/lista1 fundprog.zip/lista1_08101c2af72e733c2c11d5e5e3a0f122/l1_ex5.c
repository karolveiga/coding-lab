#include <stdio.h>
int main()
{
    int i1, i2, divis, rest;

    scanf("%d %d", &i1, &i2);
    //leitura das variaveis

    divis = i1 / i2;
    rest = i1 % i2;
    //opera��es matem�ticas

    printf("%d %d", divis, rest);

    return 0;
    /*a diferen�a eh que em uma opera��o n�o teve resto
    a outra teve resto*/
}
