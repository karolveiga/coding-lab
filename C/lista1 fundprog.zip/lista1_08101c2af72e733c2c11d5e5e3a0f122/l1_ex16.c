#include <stdio.h>

int main(){
    int numero, ultimoDigito;

    //lendo o numero inteiro
    scanf("%d", &numero);

    //o resto da divisao por 10 isola o ultimo digito
    ultimoDigito = numero % 10;

    //exibe apenas o ultimo digito
    printf("%d\n", ultimoDigito);

    return 0;
}
