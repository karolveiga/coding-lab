#include <stdio.h>
int main()
{
    int i;
    char c;
    float f;

    printf("Digite um valor inteiro: \n");
    scanf("%d" , &i);

    printf("Digite um caractere: \n");
    scanf(" %c", &c); //espa�o no %c para pode funcionar

    printf("Entre com um numero de ponto flutuante (valor nao inteiro): \n");
    scanf("%f", &f);

    printf("%d %c %f", i, c, f);

    return 0;
    /*o espa�o no %c foi necessario para ele n�o ler o enter, que era o
    bug que estava dando antes*/
}
