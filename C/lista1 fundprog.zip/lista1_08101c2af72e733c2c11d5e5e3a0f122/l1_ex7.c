# include <stdio.h>
int main () {
    float aux;

    printf (" Digite um numero inteiro : ");
    scanf ("%f", &aux );
    printf ("%f", aux );
    return 0;
    /*aqui da aplicar a mesma l�gica da quest�o anterior,
eh necessario mudar todas as variaveis para um float para
que o erro de execu��o nao ocorra*/
}
